package src;

public class Persona {

    private String nombre;
    private int    edad;
    private int    dni;

    public Persona(){
        this.nombre = "el mati";
        this.edad = 0;
        this.dni=-1;
    }

    public Persona(String nombre,int edad){
        this.nombre = nombre;
        this.edad = edad;
    }

    public void sayPersonaData(){
        System.out.println("Nombre: " + this.nombre + " Edad: " + this.edad);        
    }

    public String getNombre()         { return this.nombre; }
    public float  getEdad()           { return this.edad;   }
    public int    getDni()            { return this.dni;    }

    public void setNombre(String name){ this.nombre = name; }
    public void setEdad  (int edad   ){ this.edad   = edad; }
    public void setDni   (int dni    ){ this.dni    = dni;  }

    /*public static void main(String[] args) {
        System.out.println("picantovich");
        Persona a = new Persona();
        Persona b = new Persona();
        if(
            this.nombre == a.getNombre(); &&
            this.edad   == a.getEdad()
        ){
            return true;
        }else{
            return false;
        }
    }*/


}