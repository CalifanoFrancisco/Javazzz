package src;
import java.util.Scanner;
import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
	  
		boolean menu1=true;

		SistemaDeRegistroDePersonas srp = new SistemaDeRegistroDePersonas();
		srp.rellenoParaTesteo();
		boolean nashe=true;		

		while(menu1){

			System.out.println("1. Registrar persona. 		 ");
			System.out.println("2. Eliminar persona.  		 ");
			System.out.println("3. Modificar nombre persona. ");
			System.out.println("4. Modificar edad persona.   ");
			System.out.println("5. Decir  mayores de edad.   ");
			System.out.println("6. Decir todas las personas. ");
			System.out.println("7. Salir                     ");

			Scanner eleccionInput = new Scanner(System.in);
			int eleccion = eleccionInput.nextInt();

			switch(eleccion){
				case 1:
					int tamanio = srp.tamanioArray();
					srp.addPerson();

					//System.out.println("pos: "+tamanio);
					System.out.println("Insertar nombre: ");
					Scanner nameInput = new Scanner(System.in);
					String  nombre    = nameInput.nextLine();
					srp.changeName(tamanio, nombre);

					System.out.println("Insertar edad: ");
					Scanner edadInput = new Scanner(System.in);
					int     edad      = edadInput.nextInt();
					srp.changeEdad(tamanio, edad);
				break;
				case 2:
					nashe=true;
					System.out.println(" ");
					while(nashe){
						srp.sayAllPersonas();
						System.out.println("Elija persona a borrar: ");
						Scanner dniInput = new Scanner(System.in);
						int     dni      = dniInput.nextInt();
	
						if(dni <= srp.tamanioArray() && dni>=0){
							System.out.println("Persona " + dni + " eliminada exitosamente.");
							srp.removePerson(dni);
							nashe=false;
						}else{
							System.out.println("valor invalido :(");
						}
					}
					System.out.println(" ");
					
				break;
				case 3:
					System.out.println(" ");
					nashe=true;
					while(nashe){
						srp.sayAllPersonas();
						System.out.println("Elija persona a modificar nombre: ");
						Scanner dniInput = new Scanner(System.in);
						int     dni      = dniInput.nextInt();

						if(dni <= srp.tamanioArray() && dni>=0){
							System.out.println("Inserte nombre nuevo ");
							Scanner nombreInput = new Scanner(System.in);
							String  name        = nombreInput.nextLine();

							System.out.println("Nombre de persona DNI:"+dni+" modificado exitosamente.");
							srp.changeName(dni, name);
							nashe=false;
						}else{
							System.out.println("valor invalido :(");
						}
					}
				break;
				case 4: 
					System.out.println(" ");
					nashe=true;
					while(nashe){
						srp.sayAllPersonas();
						System.out.println("Elija persona a modificar edad: ");
						Scanner dniInput = new Scanner(System.in);
						int     dni      = dniInput.nextInt();

						if(dni <= srp.tamanioArray() && dni>=0){
							System.out.println("Inserte nombre nuevo ");
							Scanner edaddInput = new Scanner(System.in);
							int     edadd      = edaddInput.nextInt();

							System.out.println("Edad de persona DNI:"+dni+" modificada exitosamente.");
							srp.changeEdad(dni, edadd);
							nashe=false;
						}else{
							System.out.println("valor invalido :(");
						}
					}
				break;
				case 5: 
					srp.sayMayoresEdad();
				break;
				case 6: 
					srp.sayAllPersonas();
				break;
				case 7: 	menu1=false; 								break;
				default:	System.out.println("Valor invalido :(. ");	break;

			}


		}




		
	}
	
}
