package src;

import java.util.ArrayList;

public class SistemaDeRegistroDePersonas {

    ArrayList<Persona> personas = new ArrayList<>();

    public void rellenoParaTesteo(){
        Persona p1 = new Persona("el sech",25);
        Persona p2 = new Persona("chesvil",17);
        Persona p3 = new Persona("femboyEnjoyer",2);
        Persona p4 = new Persona("polteti",19);

        personas.add(p1);
        personas.add(p2);
        personas.add(p3);
        personas.add(p4);
    }
    
    public void addPerson(){ 
        Persona aux = new Persona();
        personas.add(aux);
    }

    public void removePerson (int pos){ personas.remove(pos);   }

    public void changeName(int dni,String name){
        personas.get(dni).setNombre(name);
    }

    public void changeEdad(int dni,int edad){
        personas.get(dni).setEdad(edad);
    }

    public void sayMayoresEdad(){
        for(Persona dni:personas){
            if(personas.get(dni).getEdad() > 18){
                System.out.println( dni + ". " + personas.get(dni).getNombre() + ".");
            }
        }
        System.out.println("");

    }

    public void sayAllPersonas(){
        for(Persona dni:personas){
            System.out.println(
                dni + ". " + personas.get(dni).getNombre() + " " + personas.get(dni).getEdad() + "."
            );
        }
        System.out.println("");
    }

    public int tamanioArray(){
        return personas.size() - 0;
    }

}
